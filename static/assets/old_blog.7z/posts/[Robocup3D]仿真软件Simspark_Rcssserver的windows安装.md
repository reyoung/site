---
title: Robocup3D仿真软件Simspark_Rcssserver的windows安装
date: '2013-06-30'
description:
categories:
-Robocup3D
comments: true
---

Simspark和Rcssserver是Robocup3D仿真比赛的仿真服务器。这两个套件是跨平台的。所以，在windows下也可以安装。官方给出了二进制的安装包，但是在安装过程中，可能有一些问题。摘录如下。

## 下载安装二进制安装包

simspark项目托管在sf.net上(吐槽，当时还木有github,google code之类的呢。。)。其中，simspark的安装包可以在这里找到，而rcssserver的安装包可以在这里找到。

分别下载两个安装包，将对应软件装到随意的位置里。(例如，simspark装到D:\Simspark\, Rcssserver装到D:\Rcssserver)

## 添加环境变量

这时候，装好了以后，尝试运行rcssserver中的bin目录下的rcsoccersim3d.cmd，是会报错的。用记事本打开rcsoccersim3d.cmd，可以看到如下内容:

    start cmd /c "%RCSSSERVER3D_DIR%\bin\rcssserver3d.cmd"
    start /b /wait cmd /c "%RCSSSERVER3D_DIR%\bin\rcssmonitor3d.cmd"
	
可以看到这个cmd实际上是启动了两个其他的cmd，那么分别打开剩下两个cmd看看，比如看一下rcssserver3d.cmd

    PATH %PATH%;%SPARK_DIR%\lib\simspark;%SPARK_DIR%\lib\thirdparty;%RCSSSERVER3D_DIR%\lib\rcssserver3d
    cd "%RCSSSERVER3D_DIR%\bin\"
    rcssserver3d.exe %1 %2 %3 %4
	
可以看到在这个cmd中，实际上是根据环境变量SPARK_DIR和RCSSSERVER3D_DIR对环境变量PATH进行了设置。然后运行了rcssserver3d.exe

但是，他的安装包里面并没有对SPARK_DIR和RCSSSERVER3D_DIR进行设置过。所以，应该设置一下这两个环境变量。具体方法可以参考下面的图片。

<img src="{{urls.media}}/robocup3d/rcssserver-295x300.jpg">

## 调整PATH变量的位置

经过上面的设置，将两个环境变量设置成为对应的安装目录，运气好的话，就可以运行rcsoccersim3d了。但是，还有可能在运行的时候，报各种dll错误。这是为什么呢？

仔细看一下上一节中cmd文件的path变量方法，显然他的顺序是不和谐的。在这一行:

    PATH %PATH%;%SPARK_DIR%\lib\simspark;%SPARK_DIR%\lib\thirdparty;%RCSSSERVER3D_DIR%\lib\rcssserver3d
	
他将旧的PATH放到了前面，而把simspark和rcssserver的path放到了后面，这样，如果在原来path中有一些dll和simspark或者rcssserver的dll重名，那么就会先引用原来path中的dll。如果两个dll不一样，无论是版本还是实现的功能，都势必会报错。修正方法也很简单。只需要把path移动到后面就可以了

    PATH %SPARK_DIR%\lib\simspark;%SPARK_DIR%\lib\thirdparty;%RCSSSERVER3D_DIR%\lib\rcssserver3d;%PATH%
	
这样，不意外的话，应该就可以运行rcsoccersim3d了。

事实上，想要在windows下安装simspark和rcssserver，还是很容易的。如果不讲原因，三五句话也就搞定了。。这里写这么多，主要阐释了为什么这么做。希望给别人或者别的项目以启示吧。。