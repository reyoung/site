---
title: AIMA读书笔记1
date: '2013-08-19'
description:
categories:
	- note
	- learning
tags:
	- note
	- AI
	- AIMA
---

<img src="{{urls.media}}/aima_note/1/AIMA.jpg" width="640px"/>

<img src="{{urls.media}}/aima_note/1/AIMA2.jpg" width="640px"/>

<img src="{{urls.media}}/aima_note/1/AIMA3.jpg" width="640px"/>

<img src="{{urls.media}}/aima_note/1/AIMA4.jpg" width="640px"/>