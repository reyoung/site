---
title: maven使用.01.Hello World
date: '2013-07-11'
description:
categories: Tutorials
tags: 
- maven
- java 
---

要说Java世界有什么东西是我最为留恋的；在写其他语言程序的时候，我最为想要的东西，那非maven莫属。

## 什么是Maven？

### Maven能做什么？

Maven是一个针对Java的自动构建工具。所谓自动构建，就是在命令行里面敲一条命令，而替代程序员手动去编译每一个java文件，在打成jar包的过程。这听起来没什么，尤其是对于本来使用IDE的程序员们来说。但是Maven还可以做到:

* 依赖的引入。 不用程序员去手动的下载第三方的jar，只需要修改配置文件，便可以引入jar包。
* 良好的测试集成。  maven对于"如果想要在打包前进行测试，如果测试不通过不打包"这种需求很容易做到。
* 良好子项目管理。  maven对于项目来说，可以有一个大项目包括N个子项目构成。而不是像eclipse，只可以有一个根项目。
* 良好的持续集成。  使用maven，对于daily build的支持，对于每次提交的代码的检查，简直是易如反掌。

总之，如果你原来只是使用过eclipse进行java开发，maven绝对值得你去接触。而且事实上，如此好的工具，也在java世界里用的非常广。

### 类似的工具

类似于Maven的工具也不少，相较于maven有这样和那样的不同，仅就我知道的java世界的自动构建工具，列举一下:

* SBT 
	* 优点: 绝佳的Scala支持，绝佳的开发体验
	* 缺点: 集成测试上设置起来远比Maven麻烦，学习曲线也不小(尤其是对于不懂Scala的Java团队)
* Ant+Ivy
	* 优点: 可配置性强
	* 缺点: 配置的东西太多，不够简单
* Gradle
	* 应该是非常不错的工具，只是没有尝试过。

### Maven的缺点

说了这么多好的东西，难道Maven就没有自身的问题么？当然是有的。下面说一下主要的缺点:

* Maven的编译时间更慢。因为他在编译的时候，检查的东西更多。(比如依赖有没有下载等)
* Maven使用XML配置，这既是优点也是缺点。缺点在于，XML文件大部分时候是冗长的。但是，目前的IDE对于XML的支持还是不错的，写起来效率也不算慢。
	
## Maven的Hello World

说了这么多，基本上就是想说，如果你需要一个java第三方库的依赖管理，更好地测试运行，更通用的项目文件，使用Maven绝对不错。但是说了这么多，如何使用呢？还是从Hello World将起。

### Maven的安装

在maven安装之前，需要你的电脑上安装一个JDK，并将JAVA_HOME环境变量设置成JDK的安装路径。

例如把JAVA_HOME设置成C:\Program Files\Java\jdk1.7.0_01之类的。


#### Windows下的安装

首先呢，要下载maven的二进制文件。[下载页面](http://maven.apache.org/download.cgi)和[二进制文件](http://apache.mirrors.lucidnetworks.net/maven/maven-3/3.1.0-alpha-1/binaries/apache-maven-3.1.0-alpha-1-bin.tar.gz)在这里。

在下载之后，将压缩包解压到相应的目录，例如为C:\apache-maven-3.1.0\，并确定C:\apache-maven-3.1.0\bin目录是存在的。

然后设置环境变量:

* M2_HOME设置为Maven的home路径，例如C:\apache-maven-3.1.0\
* PATH目录，添加M2_HOME的bin目录，例如C:\apache-maven-3.1.0\bin

如果，不想修改全局环境变量的话，可以将下面的文件保存成一个bat，然后运行一下，就会将环境变量设置好了。

	@ECHO OFF
	:: You Should Change M2_HOME fit for your install
	set M2_HOME=C:\apache-maven-3.1.0
	set PATH=%M2_HOME%\bin;%PATH%
	cmd

安装好之后，在命令行里，输入mvn --help，就可以看的maven的帮助了。

#### Linux下的安装

和windows一样，也是需要设置环境变量。只是linux设置环境变量的方法不一样。可以在解压缩后，修改~/.bashrc。在~/.bashrc后，添加几行

	# You Should Change M2_HOME fit for your install
	export M2_HOME=/home/reyoung/maven/
	export PATH=$M2_HOME/bin:$PATH
	
如果安装完毕后，输入mvn --help，也会看的maven的帮助。

同时，不同发行版，本身也许自带maven的软件包，可以搜索安装一下。(利用yum或者apt-get或者emerge等)

### 使用Maven新建项目
	
在设置好环境变量后，在适合新建项目的目录里，输入:
	
	mvn archetype:generate -DarchetypeGroupId=org.apache.maven.archetypes

然后根据命令行的提示，依次输入选择的archetypeId, version, groupId, artifactId，就可以建立一个hello world项目了。

其中，
* 在第一个选择的时候，也就是archetypeId的时候，可以直接敲入回车。直接敲入回车，会使用quickstart的archetype。
* groupId就是软件的组织名。一般是网址的逆序，例如 me.reyoung。
* artifactId就是项目名，例如 helloworld
* version就是你这个项目的版本号。

这里如果项目建立完毕后，当前目录里就会多出一个项目目录，例如helloworld。进入那个目录，输入mvn compile就会编译该项目，输入mvn test就会测试该项目，输入mvn package就会将项目打包成jar文件。

这样简单地Hello world就搞定了。maven其他的功能、约定和设置，在下一篇文章中会说。做个预告吧。
	
## Maven的IDE集成

Java世界的IDE对Maven还是非常支持的。这里分IDE介绍一下吧。

### IntelliJ Idea

IntelliJ Idea是目前(我认为)最好的Java IDE。而且社区版开源免费。[下载地址](http://www.jetbrains.com/idea/download/index.html)。在IntelliJ Idea中，Maven项目文件可以直接被打开，同时可以和IntelliJ Idea本身的项目文件互相转化。所以，对Maven的支持还是非常不错的。 

同时，在IntelliJ Idea中，也可以新建Maven项目，之前命令行输入的命令，都可以在IntelliJ Idea中解决。推荐使用Maven的java程序员尝试一下IntelliJ Idea。


### Netbeans

如果IntelliJ Idea对Maven的支持非常好的话，那Netbeans完全就是原生支持。因为Netbeans支持使用Maven的项目文件直接做为自身的项目文件。也就是Netbeans对于Maven项目支持的和他自身的项目文件一样好。

### Eclipse

Eclipse使用插件解决maven支持问题，叫做[M2Eclipse](http://eclipse.org/m2e/)，但是eclipse天生的没有层次的项目结构，所以，eclipse本身对于maven支持并不很好。