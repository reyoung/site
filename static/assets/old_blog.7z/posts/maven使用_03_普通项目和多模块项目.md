---
title: maven使用.03.普通项目和多模块项目
date: '2013-07-14'
description:
categories: Tutorials
tags: 
- maven
- java 
---

上两个POST将概念讲述的非常完备。并在[第一篇POST](http://reyoung.me/Tutorials/maven%E4%BD%BF%E7%94%A8.01.Hello-World/)中，建立了一个Hello World程序，那么这篇日志会在第一篇的基础上，实际的写一些代码，并通过maven进行测试。

## 编写一个简单地类

使用你喜欢的IDE打开之前新建的Hello world程序，在src/main/java目录下，添加对应的包和类。即可向程序中添加一个类。例如，添加如下的类

	package me.reyoung.mvntest;

	public class SimpleAdder {
	    public static int add(int a,int b){
	        return a+b;
	    }
	}

并在src/test/java目录下，添加对应的测试文件。例如添加如下的测试类:

	package me.reyoung.mvntest;

	import junit.framework.TestCase;

	public class SimpleAdderTest extends TestCase {
	    public void testAdd() throws Exception {
	        assertEquals(3,SimpleAdder.add(1,2));
	        assertEquals(5,SimpleAdder.add(2,3));
	        assertEquals(0,SimpleAdder.add(0,0));
	    }
	}

值得注意的是，在test目录下的所有测试，应该符合你所使用的测试框架的一些标准。比如，在默认情况下，maven会引入junit3。所以，每一个该目录下的文件，在默认情况下，均应该符合junit3 标准。

### 运行测试

写完之前的程序后，就可以在该项目的目录里，运行测试了。执行命令
	
	mvn test
	
程序就会输出一些编译过程的信息，在这些信息中，有一些测试结果的信息，类似于:

	-------------------------------------------------------
	 T E S T S
	-------------------------------------------------------
	Running me.reyoung.mvntest.SimpleAdderTest
	Tests run: 1, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0.025 sec

	Results :

	Tests run: 1, Failures: 0, Errors: 0, Skipped: 0
	
并且可以在target/surefire-reports中，看到这次测试的报告。

## 多模块的maven项目

Maven项目可以是多模块的项目，这样子的话，各个子项目(模块)之间可以互相依赖，而在根项目中，可以根据这些依赖自动的按照顺序构建各个的子项目。

一个简单地多模块项目的

	<project xmlns="http://maven.apache.org/POM/4.0.0"
	         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
	                             http://maven.apache.org/maven-v4_0_0.xsd">
	    <modelVersion>4.0.0</modelVersion>

	    <groupId>org.sonatype.mavenbook.multi</groupId>
	    <artifactId>simple-parent</artifactId>
	    <packaging>pom</packaging>
	    <version>1.0</version>
	    <name>Multi Chapter Simple Parent Project</name>

	    <modules>
	        <module>simple-weather</module>
	        <module>simple-webapp</module>
	    </modules>

	    <build>
	        <pluginManagement>
	            <plugins>
	                <plugin>
	                    <groupId>org.apache.maven.plugins</groupId>
	                    <artifactId>maven-compiler-plugin</artifactId>
	                    <configuration>
	                        <source>1.5</source>
	                        <target>1.5</target>
	                    </configuration>
	                </plugin>
	            </plugins>
	        </pluginManagement>
	    </build>

	    <dependencies>
	        <dependency>
	            <groupId>junit</groupId>
	            <artifactId>junit</artifactId>
	            <version>3.8.1</version>
	            <scope>test</scope>
	        </dependency>
	    </dependencies>
	</project>

可以看到，这个pom文件，和之前的hello word的pom文件有这么几点区别。

* 这个项目文件的packaging是pom，因为这个项目是maven的多模块项目的主项目，而不会像之前一样，生成jar包
* 这个项目有modules标签，而其中有两个子标签，simple-weather和simple-webapp，这两个就是分别的子项目。

NOTE: 在这个pom文件里，其他的设置，都是对这个项目的所有子项目的设置。例如，在这个pom中依赖junit，那么对于simple-weather和simple-webapp都会依赖与junit。


### 子项目simple-weather

simple-weather的pom文件如下:

	<project xmlns="http://maven.apache.org/POM/4.0.0"
	         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
	                             http://maven.apache.org/maven-v4_0_0.xsd">
	    <modelVersion>4.0.0</modelVersion>
	    <parent>
	        <groupId>org.sonatype.mavenbook.multi</groupId>
	        <artifactId>simple-parent</artifactId>
	        <version>1.0</version>
	    </parent>
	    <artifactId>simple-weather</artifactId>
	    <packaging>jar</packaging>

	    <name>Multi Chapter Simple Weather API</name>

	    <build>
	        <pluginManagement>
	            <plugins>
	                <plugin>
	                    <groupId>org.apache.maven.plugins</groupId>
	                    <artifactId>maven-surefire-plugin</artifactId>
	                    <configuration>
	                        <testFailureIgnore>true</testFailureIgnore>
	                    </configuration>
	                </plugin>
	            </plugins>
	        </pluginManagement>
	    </build>

	    <dependencies>
	        <dependency>
	            <groupId>log4j</groupId>
	            <artifactId>log4j</artifactId>
	            <version>1.2.14</version>
	        </dependency>
	        <dependency>
	            <groupId>dom4j</groupId>
	            <artifactId>dom4j</artifactId>
	            <version>1.6.1</version>
	        </dependency>
	        <dependency>
	            <groupId>jaxen</groupId>
	            <artifactId>jaxen</artifactId>
	            <version>1.1.1</version>
	        </dependency>
	        <dependency>
	            <groupId>velocity</groupId>
	            <artifactId>velocity</artifactId>
	            <version>1.5</version>
	        </dependency>
	        <dependency>
	            <groupId>org.apache.commons</groupId>
	            <artifactId>commons-io</artifactId>
	            <version>1.3.2</version>
	            <scope>test</scope>
	        </dependency>
	    </dependencies>
	</project>
	
可以看到这个pom.xml中，和之前的hello world的pom类似。里面也是具有依赖结构和maven的座标。唯一一个区别，就是多了一个parent标签。而这个parent标签就是指定这个项目的parent。

### 多模块项目的目录结构

	simple-parent
	|--- pom.xml
	|--- simple-weather
	|    |--- pom.xml
	|    |--- src
	|    |    |--- main
	|    |    `--- test
	|    `--- target
	`--- simple-webapp
	     |--- pom.xml
		 |--- src
		 |    |--- main
		 |    `--- test
		 `--- target

可以看出，对于多模块的maven项目，每个子项目放到相应的目录里。这样，如果要整体构建这个多模块项目，就可以使用
	mvn compile
一下。

这样，对于maven多模块项目，就简单地介绍在这里。

## 引用

* [MultiModule](http://books.sonatype.com/mvnex-book/reference/multimodule.html)
