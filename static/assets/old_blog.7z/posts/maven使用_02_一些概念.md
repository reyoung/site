---
title: maven使用.02.一些概念
date: '2013-07-12'
description:
categories: Tutorials
tags: 
- maven
- java 
---

在上一篇POST中，简要的介绍了一下maven的特点，优势，安装。并建立了一个简单地Hello world工程。这一篇POST中，将主要会介绍一下Maven的一些约定。

## pom.xml文件

Maven的项目文件是一个XML文件，叫做pom.xml，取Project Object Model的意思。对于项目的配置，都是修改POM.xml完成的。

一个简单地pom配置文件如下：

	<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	  xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
	  <modelVersion>4.0.0</modelVersion>

	  <groupId>me.reyoung</groupId>
	  <artifactId>helloworld</artifactId>
	  <version>1.0-SNAPSHOT</version>
	  <packaging>jar</packaging>

	  <name>helloworld</name>
	  <url>http://maven.apache.org</url>

	  <properties>
	    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
	  </properties>

	  <dependencies>
	    <dependency>
	      <groupId>junit</groupId>
	      <artifactId>junit</artifactId>
	      <version>3.8.1</version>
	      <scope>test</scope>
	    </dependency>
	  </dependencies>
	</project>

可以看到，pom.xml是个标准的XML文件。其中前三行说明这是一个maven格式的XML文件。在第5行到第8行说明了当前项目的一系列信息。而这些信息是Maven的座标信息。

### Maven座标信息

Maven座标信息指的是每一个maven工程所独有的一个ID，而且，对于同一工程，不同的版本对应的座标不同。常见的座标包括有groupId:artifactId:version。其中:

* groupId: 基本上这个属性描述的是谁或者是哪个组织写的这个项目
* artifactId: 构建的ID，表示这个项目在那个组织中的名字
* version: 项目的版本。这里以SNAPSHOT结尾，表示该项目还是一个正在开发中的快照版本。
* packaging: 该项目的打包方式，例如
	* 对于桌面应用和程序库，打包成jar
	* 对于网络应用打包成war
	* 对于maven的扩展或者子项目等等在maven系统中用的项目，打包成pom

使用这些座标，就可以定义出每一个Maven项目构建出来的结果了。比如，想找到图数据库Neo4J的座标。在maven的[中心库](http://search.maven.org)搜索出的座标为 org.neo4j:neo4j:2.0.0-M03

### Dependencies 信息

在pom.xml文件的Dependencies中，描述了这个项目依赖的第三方库。而对于每个第三方库，

* 如果这个第三方库，可以在maven的[中心库](http://search.maven.org)搜索到，那么直接在Dependencies中，添加这个Dependency的maven座标就可以了。

* 如果这个第三方库，不再maven的[中心库](http://search.maven.org)中，那么可以有几种方法实现。这个在今后的博客中再讨论。

## maven的项目结构

介绍完毕maven的项目配置文件pom.xml，下面说一下maven的项目结构。

大家可能很奇怪，对于maven的工程文件pom.xml做了很多描述这个项目的工作，但是并没有指定任何项目包含的文件。这就说到了maven的一个准则了。就是*约定大于编码*。也就是，在maven中，很多东西都是约定俗成的，如果你不想遵守这个约定而使用maven，就会变得复杂。

### maven的目录结构

一个常见的maven项目目录结构为:

	my-app
	|-- pom.xml
	|-- src
	|   |-- main
	|   |   `-- java
	|   |       `-- com
	|   |           `-- mycompany
	|   |               `-- app
	|   |                   `-- App.java
	|   `-- test
	|       `-- java
	|           `-- com
	|               `-- mycompany
	|                   `-- app
	|                       `-- AppTest.java
	`-- target
		|-- *.jar
		`-- *

其中，根目录里包括src目录和target目录。

* src目录为源代码目录，包括该项目所有的代码或者资源文件。
	* src下的main目录，包括所有的正式代码。
		* 代码子目录。 而在这个目录下的java子目录，表示该程序所有的java代码。其他语言的代码，均为其他语言的目录，例如scala目录等。
		* 资源子目录。 包括resources目录，这个目录在编译成jar的时候，会打包进入jar。当然还有其他的资源，例如web资源等。
	* src下的test目录，包括所有测试运行时的代码。其子目录结构和src/main中的一样。
* target目录为编译的结果目录。包括编译后的class文件，jar文件，也包括生成的测试报告。

这样，常见的maven项目目录格式，就是这样了。可见，maven系统中的所包括的代码，便是src目录下的所有源文件。

## Maven的命令或者叫做生命周期(Life Cycle)

Maven包括一组命令。例如mvn compile就是编译，mvn test就是运行测试等。在maven这组命令中，基本上包括了软件开发从依赖解决到部署的全部内容。maven官方称这些为Build Life Cycle。而build life cycle包括:

* validate - 验证项目是否正确，所有的依赖能否达到
* compile - 编译源代码
* test - 测试代码
* package - 将编译好的源代码打包
* verify - 验证这个包是不是正确
* install - 将这个构建安装到本地的maven库中
* deploy - 将这个构建上传到远端的maven库中

同时，这些命令也可以组合使用。例如，我想要先删除之前编译的东西，然后再编译，然后测试，然后打包，然后安装到本地，就可以输入命令

	mvn clean compile test package install

maven会按照顺序依次执行。。同时，maven命令先天的支持测试，所以对于自动化测试和持续集成，非常有帮助。可以用git的hook，监听代码版本库的变化，当test不过的时候，不予提交等等。

----

这篇介绍了一些maven中的基本概念。下一篇中会实际的写一个maven的工程，同时运用一下多模块的工程结构。做个预告。。

## 引用

* [POM Reference](http://maven.apache.org/pom.html)
* [Introduction to the Standard Directory Layout](http://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html)
* [Introduction to the Build Lifecycle](http://maven.apache.org/guides/introduction/introduction-to-the-lifecycle.html)