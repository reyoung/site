---
title: 使用RadASM在Windows下汇编环境配置
date: '2013-09-16'
description:
categories:
	- note
tags:
	- 汇编
	- RadASM
	- Windos
	- 配置
---


这篇日志介绍了如何在Windows下使用RadASM进行汇编开发，并配置Irvine的库。分为如下几个步骤:
* 安装汇编语言的集成开发环境RadASM
* 下载Irvine的开发库
* 新建项目，配置Irvine库
* 运行Hello World

## 安装汇编语言的集成开发环境RadASM

RadASM可以从[这里](http://www.onlinedown.net/soft/26097.htm)下载。下载完成后，是一个安装包，安装过程没有什么注意事项，正常的安装程序就可以了。(也许会报病毒，我用Avast检测报毒。也可以从[官方网站](http://www.oby.ro/rad_asm/)下载安装)

安装完毕后，可以找到程序RadASM

## 下载Irvine的开发库

可以在Kip Irvine的官方网站下载它书籍的配套资料。地址在[这里](http://www.kipirvine.com/asm/examples/)。大家可以下载vs2012的example就可以了。(八卦一下，下面那个Curtis Wong的Linux版本的Irvine32库，是天津大学咱的大学长黄耀龙写的。^V^)

下载完了是一个zip包。解压缩完毕了后，提取出Irvine32.inc, Irvine32.lib, Kernel32.lib, SmallWin.inc, User32.lib, VirtualKey.inc到某一个目录中

## 新建项目，配置Irvine库

<img src="{{urls.media}}//radasm/create.jpg"/>

打开RadASM，选择文件，新建工程。选择Console，填写完名称，一路下一步。

<img src="{{urls.media}}//radasm/copy.jpg" />

到目录的文件夹内，把刚才解压出来的那些文件，拷到项目的根目录。

输入课本中的示例程序:

	TITLE Add and Subtract          (AddSub.asm)

	; This program adds and subtracts 32-bit integers.

	INCLUDE Irvine32.inc

	.code
	main PROC

		mov	eax,10000h		; EAX = 10000h
		add	eax,40000h		; EAX = 50000h
		sub	eax,20000h		; EAX = 30000h
		call	DumpRegs

		exit
	main ENDP
	END main
	
点击菜单构建--构建并运行(Ctrl+Shift+F5)，会报错
	
	Test.obj : error LNK2001: unresolved external symbol _ExitProcess@4
	Test.obj : error LNK2001: unresolved external symbol _DumpRegs@0
	Test.exe : fatal error LNK1120: 2 unresolved externals

报的错是Link Error，也就是Irvine32.lib没找到。那么在源代码加入如下几行即可

	INCLUDELIB Irvine32.lib
	INCLUDELIB user32.lib
	INCLUDELIB kernel32.lib
	
现在所有的程序为:
	TITLE Add and Subtract          (AddSub.asm)

	; This program adds and subtracts 32-bit integers.

	INCLUDE Irvine32.inc
	INCLUDELIB Irvine32.lib
	INCLUDELIB user32.lib
	INCLUDELIB kernel32.lib

	.code
	main PROC

		mov	eax,10000h		; EAX = 10000h
		add	eax,40000h		; EAX = 50000h
		sub	eax,20000h		; EAX = 30000h
		call	DumpRegs

		exit
	main ENDP
	END main

运行结果为:


		EAX=00030000  EBX=7FFDE000  ECX=00000000  EDX=00401000
		ESI=00000000  EDI=00000000  EBP=0018FF90  ESP=0018FF88
		EIP=00401014  EFL=00000206  CF=0  SF=0  ZF=0  OF=0  AF=0  PF=1


	Press Enter key to continue...